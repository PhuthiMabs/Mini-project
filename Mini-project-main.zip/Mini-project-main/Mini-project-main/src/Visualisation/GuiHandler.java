package Visualisation;
/**
 * Class is used to control GUI actions and interactions
 * Let user select shelf image
 * Let user crop region & enter dates(current and expiry date)
 * Shows products, graphs, similarity, freshness etc.. can add if you want to
 * Displays using Graph Visulizer as well to show tables graphs etc..
 */
public class GuiHandler {

}
