package Visualisation;
/**
 * Just read an image and handles image loading and also feature extraction for feature class
 * Convert selected image region to grayscale 
 */
public class ImageProcessor {

}
