/**
 * A class used to store and retrieve data, not needed but we can do it if we want to
 * Load/save products and shelf data
 * Handle storage in memory or file
 * 
 */
public class DataManager {

}
