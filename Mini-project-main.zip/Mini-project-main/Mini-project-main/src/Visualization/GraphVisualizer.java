package Visualization;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.graphstream.graph.*;
import org.graphstream.graph.implementations.*;

import Storage.Product;

public class GraphVisualizer {

    private Graph graph;

    public GraphVisualizer() {
        graph = new SingleGraph("Freshness Clusters");
        graph.setAttribute("ui.stylesheet", "node { size: 20px; text-size: 14px; }");
        graph.setAttribute("ui.quality");
        graph.setAttribute("ui.antialias");
    }

    public void visualizeClusters(List<Set<Product>> clusters) {
        int clusterId = 0;

        for (Set<Product> cluster : clusters) {
            for (Product product : cluster) {
                String nodeId = product.getName() + "_" + clusterId;
                if (graph.getNode(nodeId) == null) {
                    Node node = graph.addNode(nodeId);
                    node.setAttribute("ui.label", product.getName());

                    // Set color based on freshness score
                    double score = product.getFreshnessScore();
                    if (score == 1.0) {
                        node.setAttribute("ui.style", "fill-color: green;");
                    } else if (score == 0.5) {
                        node.setAttribute("ui.style", "fill-color: yellow;");
                    } else if (score == 0.0) {
                        node.setAttribute("ui.style", "fill-color: red;");
                    } else {
                        node.setAttribute("ui.style", "fill-color: gray;");
                    }
                }
            }

            // Optionally connect products within the same cluster
            List<Product> list = new ArrayList<>(cluster);
            for (int i = 0; i < list.size(); i++) {
                for (int j = i + 1; j < list.size(); j++) {
                    String id1 = list.get(i).getName() + "_" + clusterId;
                    String id2 = list.get(j).getName() + "_" + clusterId;
                    String edgeId = id1 + "-" + id2;
                    if (graph.getEdge(edgeId) == null) {
                        graph.addEdge(edgeId, id1, id2);
                    }
                }
            }

            clusterId++;
        }

        graph.display();
    }
}
