 package DataCalculations;

import java.util.*;
import Storage.Product;

/**
 * FreshnessTracker uses a graph structure to model the relationships between products
 * based on their freshness score. Products with similar freshness are connected by edges.
 * This helps identify clusters of products that are in similar freshness states.
 */
public class FreshnessTracker {

    // The graph is represented as an adjacency list
    private Map<Product, List<Product>> graph = new HashMap<>();

    /**
     * Adds a bidirectional edge between two products in the freshness graph.
     *
     * @param a The first {@link Product} to connect
     * @param b The second {@link Product} to connect
     * @throws NullPointerException if either {@code a} or {@code b} is {@code null}
     */
    public void addEdge(Product prodA, Product prodB) {
        graph.computeIfAbsent(prodA, k -> new ArrayList<>()).add(prodB);
        graph.computeIfAbsent(prodB, k -> new ArrayList<>()).add(prodA);
    }

    /**
     * Builds the freshness graph based on similarity in freshness scores between products.
     * Products with a freshness score difference below a threshold are connected.
     *
     * @param products A list of {@link Product} objects that will be analyzed.
     */
    public void buildGraph(List<Product> products) {
        double threshold = 0.1; // Max allowable difference in freshness scores to be considered similar

        for (int x = 0; x < products.size(); x++) {
            for (int y = x + 1; y < products.size(); y++) {
                double score1 = products.get(x).getFreshnessScore();
                double score2 = products.get(y).getFreshnessScore();
                double diff = Math.abs(score1 - score2);

                if (diff <= threshold) {
                    addEdge(products.get(x), products.get(y));
                }
            }
        }
    }

    /**
     * Finds clusters of products that are similar in freshness.
     * Each cluster represents a group of interconnected products in the graph.
     *
     * @return A list of product sets, where each set is a connected subgraph (cluster).
     */
    public List<Set<Product>> getFreshnessClusters() {
        Set<Product> visited = new HashSet<>();
        List<Set<Product>> clusters = new ArrayList<>();

        for (Product product : graph.keySet()) {
            if (!visited.contains(product)) {
                Set<Product> cluster = new HashSet<>();
                depthSearch(product, visited, cluster);
                clusters.add(cluster);
            }
        }

        return clusters;
    }

    /**
     * Depth-first search to explore a cluster of connected products.
     *
     * @param current  The current product node being visited
     * @param visited  Set to keep track of already visited products
     * @param cluster  The cluster being constructed
     */
    private void depthSearch(Product current, Set<Product> visited, Set<Product> cluster) {
        visited.add(current);
        cluster.add(current);

        for (Product neighbor : graph.getOrDefault(current, new ArrayList<>())) {
            if (!visited.contains(neighbor)) {
                depthSearch(neighbor, visited, cluster);
            }
        }
    }

    /**
     * Debugging utility that prints out the structure of the freshness graph.
     */
    public void printGraph() {
        for (Product product : graph.keySet()) {
            System.out.print(product.getName() + " -> ");
            for (Product neighbor : graph.get(product)) {
                System.out.print(neighbor.getName() + ", ");
            }
            System.out.println();
        }
    }
}
