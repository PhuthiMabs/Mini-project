package DataCalculations;

import java.util.*;
import Storage.Product;

public class GroupClust {

    private FreshnessTracker tracker;

    public GroupClust(FreshnessTracker tracker) {
        this.tracker = tracker;
    }

    public Map<String, List<Set<Product>>> groupClusters() {
        Map<String, List<Set<Product>>> grouped = new HashMap<>();
        grouped.put("Fresh", new ArrayList<>());
        grouped.put("Rotate", new ArrayList<>());
        grouped.put("Expired", new ArrayList<>());

        for (Set<Product> cluster : tracker.getFreshnessClusters()) {
            double avgScore = cluster.stream()
                                     .mapToDouble(Product::getFreshnessScore)
                                     .average()
                                     .orElse(0.0);

            if (avgScore >= 0.8) {
                grouped.get("Fresh").add(cluster);
            } else if (avgScore >= 0.3) {
                grouped.get("Rotate").add(cluster);
            } else {
                grouped.get("Expired").add(cluster);
            }
        }

        return grouped;
    }
}
