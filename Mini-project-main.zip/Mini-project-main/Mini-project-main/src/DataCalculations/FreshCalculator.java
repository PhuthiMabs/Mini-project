package DataCalculations;

import java.util.*;
import java.util.concurrent.TimeUnit;

import Storage.FreshnessLvl;
import Storage.Product;

/**
 * Calculates and assigns freshness levels based on calculations from expiry date
 * updates product statuses(FRESH ,....)
 */
public class FreshCalculator {
	
	
	  // Freshness evaluation based on expiry date
    public static FreshnessLvl evaluateFreshness(Product Prod) {
        long now = System.currentTimeMillis();
        long diff = Prod.getExpiryDate().getTime() - now ;

        long daysLeft = TimeUnit.MILLISECONDS.toDays(diff);

        if (daysLeft <= 0) {
            return FreshnessLvl.EXPIRED;
        } else if (daysLeft <= 2) {
            return FreshnessLvl.ROTATE;
        } else {
            return FreshnessLvl.FRESH;
        }
    }

    // Update product freshness based on the evaluation
    public void updateProductFreshness(Product product) {
        FreshnessLvl freshness = evaluateFreshness(product);
        product.setFresh(freshness);
    }

    // Build the graph from products based on freshness similarity
    public List<Set<Product>> buildGraphAndUpdateFreshness(List<Product> products) {
        // First, update freshness for all products
        for (Product product : products) {
            updateProductFreshness(product);
        }

        // Then build the graph based on freshness similarity
        return buildGraph(products);
    }

    // Build the graph based on freshness similarity
    private List<Set<Product>> buildGraph(List<Product> products) {
        Map<Product, List<Product>> graph = new HashMap<>();
        double threshold = 0.1;  // Example threshold for similarity in freshness

        // Create edges between products with similar freshness levels
        for (int i = 0; i < products.size(); i++) {
            for (int j = i + 1; j < products.size(); j++) {
            	double diff = Math.abs(products.get(i).getFreshnessScore() - products.get(j).getFreshnessScore());

                if (diff <= threshold) {
                    graph.computeIfAbsent(products.get(i), k -> new ArrayList<>()).add(products.get(j));
                    graph.computeIfAbsent(products.get(j), k -> new ArrayList<>()).add(products.get(i));
                }
            }
        }

        // Find freshness clusters
        return getFreshnessClusters(graph);
    }

    // Find clusters of connected products based on freshness similarity
    private List<Set<Product>> getFreshnessClusters(Map<Product, List<Product>> graph) {
        Set<Product> visited = new HashSet<>();
        List<Set<Product>> clusters = new ArrayList<>();

        // Perform DFS to find connected clusters
        for (Product p : graph.keySet()) {
            if (!visited.contains(p)) {
                Set<Product> cluster = new HashSet<>();
                dfs(p, visited, cluster, graph);
                clusters.add(cluster);
            }
        }

        return clusters;
    }

    // Depth-First Search (DFS) to traverse the graph and form clusters
    private void dfs(Product p, Set<Product> visited, Set<Product> cluster, Map<Product, List<Product>> graph) {
        visited.add(p);
        cluster.add(p);
        for (Product neighbor : graph.getOrDefault(p, new ArrayList<>())) {
            if (!visited.contains(neighbor)) {
                dfs(neighbor, visited, cluster, graph);
            }
        }
    }
	
}
