package Storage;

public enum FreshnessLvl {
	ROTATE,
	FRESH,
	EXPIRED
}
